package com.example.sudoku;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Random;

public class HelloApplication extends Application {
    private static final int SIZE = 9;

    // Store references to the text fields to extract user input later
    private TextField[][] cells = new TextField[SIZE][SIZE];

    @Override
    public void start(Stage stage) throws IOException {
        SudokuSolver algo = new SudokuSolver();
        Random rand = new Random();

        Sudoku generator = new Sudoku(rand.nextInt(10, 11));
        int[][] arr = generator.gnerate();
        GridPane grid = createSudokuGrid(arr, algo);
        Scene scene = new Scene(grid);

        stage.setTitle("Sudoku Solver");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }

    private GridPane createSudokuGrid(int[][] arr, SudokuSolver algo) {
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(11));
        grid.setVgap(5);
        grid.setHgap(5);

        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                TextField cell = new TextField();
                cell.setPrefSize(50, 50);
                cell.setStyle("-fx-font-size: 20; -fx-alignment: CENTER; -fx-min-width: 50; -fx-min-height: 50;");
                cell.setMaxWidth(50);
                cell.setMaxHeight(50);
                cell.setAlignment(javafx.geometry.Pos.CENTER);

                // Add a border around 3x3 subgrids for better visibility
                if (((row > 2 && row < 6) || (col > 2 && col < 6)) && ((row) / 3 != 1 || (col) / 3 != 1)) {
                    cell.setStyle(cell.getStyle() + "-fx-border-color: black; -fx-border-width: 2;");
                } else {
                    cell.setStyle(cell.getStyle() + "-fx-border-color: gray; -fx-border-width: 1;");
                }

                if (arr[row][col] != 0) {
                    cell.setText(String.valueOf(arr[row][col]));
                    cell.setEditable(false);
                    cell.setOpacity(0.5);
                } else {
                    // Restrict input to 1-9 for empty cells
                    TextFormatter<String> formatter = new TextFormatter<>(change -> {
                        String newText = change.getControlNewText();
                        if (newText.matches("[1-9]?")) {
                            return change; // Accept change
                        }
                        return null; // Reject change
                    });
                    cell.setTextFormatter(formatter);
                }

                // Store the text field in the cells array
                cells[row][col] = cell;
                grid.add(cell, col, row);
            }
        }
        Button solve=new Button("Solve");
        Button check = new Button("Check");
        check.setOnAction(e -> checkSolution(arr, algo)); // Set button action
        solve.setOnAction(e-> solveSolution(arr,algo));
        grid.add(check, 5, 11);
        grid.add(solve, 3, 11);

        return grid;
    }

    private void solveSolution(int[][] arr, SudokuSolver algo) {


        boolean isCorrect= SudokuSolver.sudokustart(arr);

        // Check if the user's solution is valid


        // Show an alert with the result
        if (isCorrect) {
            int[][] userGrid = SudokuSolver.board;
            // Extract the user's input from the grid
            for (int row = 0; row < SIZE; row++) {
                for (int col = 0; col < SIZE; col++) {
                    cells[row][col].setText(String.valueOf(userGrid[row][col]));

                }
            }

        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);

            alert.setContentText("The Sudoku cant be SolvedTry again.");
            alert.show();
        }

    }

    // Method to check the solution against the correct Sudoku solution
    private void checkSolution(int[][] initialGrid, SudokuSolver algo) {
        int[][] userGrid = new int[SIZE][SIZE];
        // Extract the user's input from the grid
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                String text = cells[row][col].getText();
                if (!text.isEmpty()) {
                    userGrid[row][col] = Integer.parseInt(text);
                } else {
                   userGrid[row][col]=0;
                }
            }
        }
        algo.printBoard(userGrid);
        boolean isCorrect;

            isCorrect= algo.checksolution(userGrid);

        // Check if the user's solution is valid


        // Show an alert with the result
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        if (isCorrect) {
            alert.setContentText("Congratulations! The solution is correct.");
        } else {
            alert.setContentText("The solution is incorrect. Try again.");
        }
        alert.show();
    }
}
