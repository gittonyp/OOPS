package com.example.demo;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Modality;
import javafx.stage.Popup;
import javafx.stage.PopupWindow;
import javafx.stage.Stage;
import java.lang.*;
import java.io.IOException;

public class HelloApplication extends Application {
    poly p1=new poly();
    @Override
    public void start(Stage stage) throws IOException {
        Label nameofapp=new Label("Shapes");

        Button rectanglebutton=new Button("Rectangle");
        Button Circle=new Button("Circle");
        HBox h1=new HBox(rectanglebutton,Circle);
        VBox grdi=new VBox(nameofapp,h1);
        Circle.setOnAction( e->showcircle());
        rectanglebutton.setOnAction(e->showRectangle());
        Scene scene = new Scene(grdi, 300, 150);
        stage.setTitle("Hello!");

        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }

    public void showcircle(){
        Stage shr=new Stage();
        Circle c1=new Circle(100, Color.BLUE);
        shr.initModality(Modality.APPLICATION_MODAL);
        Label l1s=new Label("Which Operation");
        Button per=new Button("Perimeter");
        Button are=new Button("Area");
        per.setOnAction(e->pericircle());
        are.setOnAction(e->areacircle());
        HBox h1=new HBox(per,are);
        VBox forcircle=new VBox(c1,l1s,h1);
        Scene showc=new Scene(forcircle);
        shr.setScene(showc);
        shr.show();
    }
    public void pericircle(){
        Stage shr=new Stage();
        Circle c1=new Circle(100, Color.BLUE);
        shr.initModality(Modality.APPLICATION_MODAL);
        Label l1s=new Label("Enter Radius");
        TextField text=new TextField();
        Button submit=new Button("Submit");
        Label showres=new Label();

        submit.setOnAction(e->{

            double Area1;

            try {
                Area1=Integer.parseInt(text.getText());
            }
            catch (NumberFormatException){
                Stage pop1=new Stage();
                Label alert=new Label("Wrong Input");
                VBox alev=new VBox(alert);
                Scene sp1=new Scene(alev);
                pop1.setScene(sp1);
                pop1.show();
            }
            Area1=p1.per(Area1);

            showres.setText(String.valueOf(Area1));
        });

        VBox forcircle=new VBox(c1,l1s,text,submit,showres);
        Scene showc=new Scene(forcircle);
        shr.setScene(showc);
        shr.show();
    }

    public void areacircle(){
        Stage shr=new Stage();
        Circle c1=new Circle(100, Color.BLUE);
        shr.initModality(Modality.APPLICATION_MODAL);
        Label l1s=new Label("Enter Radius");
        TextField text=new TextField();
        Button submit=new Button("Submit");
        Label showres=new Label();

        submit.setOnAction(e->{

            double Area1;

            try {
                Area1=Integer.parseInt(text.getText());
            }
            catch (NumberFormatException){
                Stage pop1=new Stage();
                Label alert=new Label("Wrong Input");
                VBox alev=new VBox(alert);
                Scene sp1=new Scene(alev);
                pop1.setScene(sp1);
                pop1.show();
            }


            Area1=p1.Areaa(Area1);

            showres.setText(String.valueOf(Area1));
        });

        VBox forcircle=new VBox(c1,l1s,text,submit,showres);
        Scene showc=new Scene(forcircle);
        shr.setScene(showc);
        shr.show();
    }
    public void showRectangle(){
        Stage shr=new Stage();
        Rectangle rec1=new Rectangle(100,80,Color.DARKTURQUOISE);
        shr.initModality(Modality.APPLICATION_MODAL);
        Label l1s=new Label("Enter Operation");
        Button per=new Button("Perimeter");
        Button are=new Button("Area");
        per.setOnAction(e->perirect());
        are.setOnAction(e->arearect());
        HBox h1=new HBox(per,are);
        VBox forcircle=new VBox(rec1,l1s,h1);
        Scene showc=new Scene(forcircle);
        shr.setScene(showc);
        shr.show();
    }
    public void arearect(){
        Stage shr=new Stage();
        Rectangle rec1=new Rectangle(100,80,Color.DARKTURQUOISE);
        shr.initModality(Modality.APPLICATION_MODAL);
        Label l1s=new Label("Enter Height");
        TextField text1=new TextField();
        Label l2s=new Label("Enter Width");
        TextField text2=new TextField();
        Button submit=new Button("Submit");
        Label showres=new Label();

        submit.setOnAction(e->{

            double h;
            double w;
            try {
                h = Integer.parseInt(text1.getText());
                w = Integer.parseInt(text2.getText());
            }
            catch (NumberFormatException){
                Stage pop1=new Stage();
                Label alert=new Label("Wrong Input");
                VBox alev=new VBox(alert);
                Scene sp1=new Scene(alev);
                pop1.setScene(sp1);
                pop1.show();
            }
            double Area1=p1.Areaa(h,w);

            showres.setText(String.valueOf(Area1));
        });

        VBox forcircle=new VBox(l1s,text1,l2s,text2,submit,showres);
        Scene showc=new Scene(forcircle);
        shr.setScene(showc);
        shr.show();
    }
    public void perirect(){
        Stage shr=new Stage();
        Rectangle rec1=new Rectangle(100,80,Color.DARKTURQUOISE);
        shr.initModality(Modality.APPLICATION_MODAL);
        Label l1s=new Label("Enter Height");
        TextField text1=new TextField();
        Label l2s=new Label("Enter Width");
        TextField text2=new TextField();
        Button submit=new Button("Submit");
        Label showres=new Label();

        submit.setOnAction(e->{

            double h;
            double w;

            try {
                h = Integer.parseInt(text1.getText());
                w = Integer.parseInt(text2.getText());
            }
            catch (NumberFormatException){
                Stage pop1=new Stage();
                Label alert=new Label("Wrong Input");
                VBox alev=new VBox(alert);
                Scene sp1=new Scene(alev);
                pop1.setScene(sp1);
                pop1.show();
            }

            double Area1=p1.per(h,w);

            showres.setText(String.valueOf(Area1));
        });

        VBox forcircle=new VBox(l1s,text1,l2s,text2,submit,showres);
        Scene showc=new Scene(forcircle);
        shr.setScene(showc);
        shr.show();
    }
}


class poly{
    public double Areaa(double a1,double a2){
        return a1*a2;
    }
    public double Areaa(double r){
        return 3.14*r*r;
    }
    public double per(double a1,double a2){
        return 2*a1+2*a2;
    }
    public double per(double r){
        return 3.14*r*2;
    }
}
