package com.example.snakeandball;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.Random;

public class HelloApplication extends Application {
    String direction = "DOWN";
    Random random = new Random();
    Food food = new Food();
    Timeline timeline;

    @Override
    public void start(Stage stage) {
        GridPane game = createGame();
        Scene scene = new Scene(game, 400, 400);  // Adjust size for a 20x20 grid

        // Create snake object and add to the grid
        Snake snake = new Snake();
        for (SnakeBall ball : snake.getBody()) {
            game.add(ball.getBox(), ball.x, ball.y);
        }
        // Add the food to the game initially
        game.add(food.getFoodSquare(), 5, 5);

        // Handle keypress for direction changes
        scene.setOnKeyPressed(event -> handleKeyPress(event, snake));

        // Create a timeline for continuous movement
        timeline = new Timeline(new KeyFrame(Duration.millis(200), e -> {
            snake.move(direction, game,timeline);
            foodeaten(game, snake, food);
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();

        // Set up and show the stage
        stage.setTitle("Snake!!!");
        stage.setScene(scene);
        stage.show();
    }

    private GridPane createGame() {
        GridPane gameBoard = new GridPane();

        // Initialize grid with squares
        for (int i = 0; i < 20; i++) {
            for (int j = 0; j < 20; j++) {
                Square cell = new Square();
                gameBoard.add(cell.getBox(), i, j);
            }
        }

        return gameBoard;
    }

    public static void main(String[] args) {
        launch();
    }

    void foodeaten(GridPane game, Snake snake, Food food) {
        // Assume snake eats the food when head reaches the food position
        SnakeBall head = snake.getBody().get(0);

        // Check if the snake's head is at the same position as the food
        if (head.x == GridPane.getColumnIndex(food.getFoodSquare()) &&
                head.y == GridPane.getRowIndex(food.getFoodSquare())) {

            // Move the food to a new random position
            int newFoodX = random.nextInt(20);  // Random X between 0-19
            int newFoodY = random.nextInt(20);  // Random Y between 0-19

            // Reposition the food
            GridPane.setColumnIndex(food.getFoodSquare(), newFoodX);
            GridPane.setRowIndex(food.getFoodSquare(), newFoodY);

            // Grow the snake
            snake.eat();
        }
    }

    private void handleKeyPress(KeyEvent event, Snake snake) {
        KeyCode keyCode = event.getCode();

        switch (keyCode) {
            case UP:
                if (!direction.equals("DOWN")) direction = "UP";
                break;
            case DOWN:
                if (!direction.equals("UP")) direction = "DOWN";
                break;
            case LEFT:
                if (!direction.equals("RIGHT")) direction = "LEFT";
                break;
            case RIGHT:
                if (!direction.equals("LEFT")) direction = "RIGHT";
                break;
        }
    }
}

// Updated class Square (was square)
class Square {
    private Rectangle box;

    public Square() {
        box = new Rectangle(15, 15);
        box.setFill(Color.TRANSPARENT);  // Default square is transparent
    }

    public Rectangle getBox() {
        return box;
    }
}

// Food class extending Square
class Food extends Square {
    public Food() {
        super();
        getBox().setFill(Color.RED);  // Food is red
    }

    public Rectangle getFoodSquare() {
        return getBox();
    }
}

// Snake class extending Square
class Snake extends Square {

    private ArrayList<SnakeBall> body;

    public Snake() {
        body = new ArrayList<SnakeBall>();
        SnakeBall s1 = new SnakeBall(3, 3);
        SnakeBall s2 = new SnakeBall(3, 2);
        SnakeBall s3 = new SnakeBall(3, 1);
        body.add(s1);
        body.add(s2);
        body.add(s3);
    }

    public ArrayList<SnakeBall> getBody() {
        return body;
    }

    void eat() {
        SnakeBall tail = body.get(body.size() - 1);
        // Adding new SnakeBall at the current tail's position (can modify logic for actual growth direction)
        SnakeBall newBall = new SnakeBall(tail.x, tail.y);
        body.add(newBall);
    }

    public void move(String direction, GridPane game,Timeline timeline) {
        SnakeBall head = body.get(0);

        // Calculate new head position
        int newX = head.x;
        int newY = head.y;

        switch (direction) {
            case "UP":
                newY--;
                break;
            case "DOWN":
                newY++;
                break;
            case "LEFT":
                newX--;
                break;
            case "RIGHT":
                newX++;
                break;
        }

        // Check for collision with borders
        if (newX < 0 || newY < 0 || newX >= 20 || newY >= 20) {
            System.out.println("Game over! Snake hit the wall.");
            showGameOverAlertAndExit(timeline);

        }

        // Check for collision with itself
        for (int i = 1; i < body.size(); i++) {
            if (body.get(i).x == newX && body.get(i).y == newY) {
                showGameOverAlertAndExit(timeline);
                System.out.println("Game over! Snake hit itself.");

            }
        }

        // Move the body by shifting positions (tail moves to where previous part was)
        for (int i = body.size() - 1; i > 0; i--) {
            SnakeBall prev = body.get(i - 1);
            body.get(i).x = prev.x;
            body.get(i).y = prev.y;
        }

        // Set new head position
        head.x = newX;
        head.y = newY;

        // Clear current snake position from the grid
        game.getChildren().removeIf(node -> node instanceof Rectangle && ((Rectangle) node).getFill() == Color.GREEN);

        // Redraw snake in new positions
        for (SnakeBall ball : body) {
            game.add(ball.getBox(), ball.x, ball.y);
        }
    }


    private void showGameOverAlertAndExit(Timeline timeline) {

        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Game Over");
            alert.setHeaderText(null);

            alert.setContentText("The game has ended. The snake hit the wall or itself!");
            timeline.stop();
            // Show the alert and exit the game after the alert is closed
            alert.showAndWait().ifPresent(response -> {
                System.exit(0);  // Exit the application
            });
        });
    }

}
