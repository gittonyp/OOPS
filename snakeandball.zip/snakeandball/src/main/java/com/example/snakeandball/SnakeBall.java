package com.example.snakeandball;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

class SnakeBall extends Square {
    int x;
    int y;

    public SnakeBall(int x,int y) {
        super();
        getBox().setFill(Color.GREEN);
        this.x=x;
        this.y=y;
    }
    public Rectangle SnakeBall() {
        return getBox();
    }
}
