module com.example.snakeandball {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.snakeandball to javafx.fxml;
    exports com.example.snakeandball;
}